import sys
sys.path.append("C:/Users/vince/Dropbox/My Projects")

import sqlify

# Load Census Data
places_tbl = sqlify.yield_text_table('data/2016_Gaz_place_national.txt',
                   name='places', delimiter='\t', header=True, p_key=1)
                   
for i in places_tbl: print(i)