# Compare SQL creation speeds of pandas vs sqlify
from timeit import Timer

import sys
sys.path.append("C:/Users/vince/Dropbox/My Projects")

import csv
import sqlify

import pandas as pd
import numpy as np
import sqlite3 as sql

import psycopg2
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT

def remove_revision(entry):
    return entry.split('(')[0]

# def pandas_write():
    # conn2 = sql.connect('census2010-pandas.db')

    # # Load Census Data (PANDAS)
    # my_csv = pd.read_csv('data/DEC_10_DP_DPDP1_with_ann.csv', header=0, skiprows=[1], encoding='ISO-8859-1', low_memory=False)
    # my_csv = my_csv.ix[0:, 3:374]

    # # Remove revised counts
    # my_csv['HD01_S001'] = my_csv['HD01_S001'].apply(remove_revision)
    
    # # Replace null values
    # my_csv = my_csv.replace(' ( X ) ', np.NaN)
    
    # my_csv.to_sql('table', conn2)

# pandas_t = Timer("pandas_write()", "from __main__ import pandas_write")
# t1 = pandas_t.timeit(1)
    
# # Load Census Data (sqlify)
# import sys
# sys.path.append("C:/Users/vince/Dropbox/My Projects")

# import sqlify

# def sqlify_write():
    # # Load Census Data
    # census_tbl = sqlify.csv_to_table('data/DEC_10_DP_DPDP1_with_ann.csv',
                      # name='census2010', skip_lines=2, header=0, p_key=1,
                      # na_values=' ( X ) ', col_types='TEXT')
                      
    # census_tbl.col_names[1] = 'GEOID'

    # '''
     # * HD01_S001 (population counts) sometimes have 'r(some number)' to indicate the original count was revised
     # * We want to remove this
    # '''
        
    # census_tbl['HD01_S001'].apply(remove_revision)
    # census_tbl = sqlify.subset(census_tbl, (3, 374), name='census2010')

    # sqlify.table_to_sql(census_tbl, 'census2010-sqlify.db')

# sqlify_t = Timer("sqlify_write()", "from __main__ import sqlify_write")
# t2 = sqlify_t.timeit(1)

from sqlalchemy import create_engine

conn_temp = psycopg2.connect(dbname='postgres', user='postgres', host='localhost', password='vLlvL@I@O@M8')
conn_temp.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
conn_temp = conn_temp.cursor()

# Create database if not exists
try:
    conn_temp.execute('CREATE DATABASE census_test_pandas')
except psycopg2.ProgrammingError:
    pass

try:
    conn_temp.execute('CREATE DATABASE census_test_sqlify')
except psycopg2.ProgrammingError:
    pass
    
def pandas_write_2():
    engine = create_engine('postgresql://postgres:vLlvL@I@O@M8@localhost:5432/census_test_pandas')

    # Load Census Data (PANDAS)
    my_csv = pd.read_csv('data/DEC_10_DP_DPDP1_with_ann.csv', header=0, skiprows=[1], encoding='ISO-8859-1', low_memory=False)
    my_csv = my_csv.ix[0:, 3:374]
    
    # Remove revised counts
    my_csv['HD01_S001'] = my_csv['HD01_S001'].apply(remove_revision)
    
    # Replace null values
    my_csv = my_csv.replace(' ( X ) ', np.NaN)
    
    my_csv.to_sql('census2010', engine)

def sqlify_write_2():
    # Load Census Data
    census_tbl = sqlify.csv_to_table(
                      'data/DEC_10_DP_DPDP1_with_ann.csv',
                      name='census2010',
                      header=0,
                      skip_lines=2,
                      p_key=1,
                      na_values=' ( X ) ',
                      col_types='TEXT')
                      
    census_tbl.col_names[1] = 'GEOID'

    sqlify.table_to_sql(census_tbl, 'census_test_sqlify', engine="postgres")
     
sqlify_t2 = Timer("sqlify_write_2()", "from __main__ import sqlify_write_2")
t4 = sqlify_t2.timeit(1)

pandas_t2 = Timer("pandas_write_2()", "from __main__ import pandas_write_2")
t3 = pandas_t2.timeit(1)