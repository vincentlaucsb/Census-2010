import sqlify.sqlite as sql
from statistics import mean

conn = sql.SQLTable("census2010.db", "census2010")

test = sql.preview_mutate(conn, HD01_S001="test(GEO_display_label)")